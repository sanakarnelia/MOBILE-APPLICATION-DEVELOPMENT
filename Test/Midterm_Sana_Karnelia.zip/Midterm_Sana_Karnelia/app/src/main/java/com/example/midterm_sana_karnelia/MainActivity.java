package com.example.midterm_sana_karnelia;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    Button table,history;
    EditText user_input;
    ListView listView;


    ArrayList<String> tableList = new ArrayList<>();
    ArrayAdapter<String> adapter;



    public static ArrayList<Integer> historyList = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        table =findViewById(R.id.G_btn);
        user_input=findViewById(R.id.user_input);
        history=findViewById(R.id.historybtn);
        listView=findViewById(R.id.display);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tableList);
        listView.setAdapter(adapter);

       table.setOnClickListener(v->{
           String UserInput = user_input.getText().toString().trim();

           int num=Integer.parseInt(UserInput);
           tableList.clear();
           for(int i =1; i <=10; i++){
               tableList.add(num + " x " + i +" = " +(num*i));
           }

           adapter.notifyDataSetChanged();

           if(!historyList.contains(num)){
               historyList.add(num);
}



       });





    }
}